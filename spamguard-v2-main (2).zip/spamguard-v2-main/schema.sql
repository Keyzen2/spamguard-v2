-- WARNING: This schema is for context only and is not meant to be run.
-- Table order and constraints may not be valid for execution.

CREATE TABLE public.admin_profiles (
  id uuid NOT NULL,
  role character varying DEFAULT 'viewer'::character varying CHECK (role::text = ANY (ARRAY['viewer'::character varying, 'admin'::character varying, 'superadmin'::character varying]::text[])),
  created_at timestamp without time zone DEFAULT now(),
  updated_at timestamp without time zone DEFAULT now(),
  CONSTRAINT admin_profiles_pkey PRIMARY KEY (id),
  CONSTRAINT admin_profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id)
);
CREATE TABLE public.api_keys (
  id uuid NOT NULL DEFAULT uuid_generate_v4(),
  user_id uuid,
  key_hash character varying NOT NULL UNIQUE,
  key_prefix character varying NOT NULL,
  name character varying,
  scopes ARRAY DEFAULT ARRAY['analyze'::text, 'feedback'::text, 'stats'::text],
  rate_limit_tier character varying DEFAULT 'free'::character varying,
  is_active boolean DEFAULT true,
  last_used_at timestamp without time zone,
  total_requests integer DEFAULT 0,
  created_at timestamp without time zone DEFAULT now(),
  expires_at timestamp without time zone,
  CONSTRAINT api_keys_pkey PRIMARY KEY (id),
  CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.api_users(id)
);
CREATE TABLE public.api_requests (
  id uuid NOT NULL DEFAULT uuid_generate_v4(),
  user_id uuid,
  api_key_id uuid,
  endpoint character varying,
  method character varying,
  text_length integer,
  context jsonb,
  prediction jsonb,
  processing_time_ms integer,
  ip_address inet,
  user_agent text,
  status_code integer,
  error_message text,
  created_at timestamp without time zone DEFAULT now(),
  CONSTRAINT api_requests_pkey PRIMARY KEY (id),
  CONSTRAINT api_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.api_users(id),
  CONSTRAINT api_requests_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id)
);
CREATE TABLE public.api_usage (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  site_id character varying NOT NULL,
  year_month character varying NOT NULL,
  requests_count integer DEFAULT 0,
  comments_analyzed integer DEFAULT 0,
  plan character varying DEFAULT 'free'::character varying,
  limit_reached boolean DEFAULT false,
  created_at timestamp without time zone DEFAULT now(),
  updated_at timestamp without time zone DEFAULT now(),
  CONSTRAINT api_usage_pkey PRIMARY KEY (id)
);
CREATE TABLE public.api_users (
  id uuid NOT NULL DEFAULT uuid_generate_v4(),
  email character varying NOT NULL UNIQUE,
  password_hash character varying,
  full_name character varying,
  company_name character varying,
  plan character varying DEFAULT 'free'::character varying,
  stripe_customer_id character varying,
  stripe_subscription_id character varying,
  is_active boolean DEFAULT true,
  email_verified boolean DEFAULT false,
  created_at timestamp without time zone DEFAULT now(),
  updated_at timestamp without time zone DEFAULT now(),
  last_login_at timestamp without time zone,
  CONSTRAINT api_users_pkey PRIMARY KEY (id)
);
CREATE TABLE public.comments_analyzed (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  site_id character varying NOT NULL,
  comment_content text NOT NULL,
  comment_author character varying,
  comment_author_email character varying,
  comment_author_ip inet,
  comment_author_url character varying,
  post_id bigint,
  created_at timestamp without time zone DEFAULT now(),
  features jsonb,
  predicted_label character varying,
  prediction_confidence double precision,
  actual_label character varying,
  user_agent text,
  referer text,
  CONSTRAINT comments_analyzed_pkey PRIMARY KEY (id)
);
CREATE TABLE public.feedback_queue (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  comment_id uuid,
  site_id character varying,
  old_label character varying,
  new_label character varying,
  processed boolean DEFAULT false,
  created_at timestamp without time zone DEFAULT now(),
  user_id uuid,
  CONSTRAINT feedback_queue_pkey PRIMARY KEY (id),
  CONSTRAINT feedback_queue_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments_analyzed(id),
  CONSTRAINT feedback_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.api_users(id)
);
CREATE TABLE public.learned_patterns (
  id integer NOT NULL DEFAULT nextval('learned_patterns_id_seq'::regclass),
  site_id character varying,
  pattern_type character varying,
  pattern_value text,
  spam_score double precision,
  occurrences integer DEFAULT 1,
  last_seen timestamp without time zone DEFAULT now(),
  CONSTRAINT learned_patterns_pkey PRIMARY KEY (id)
);
CREATE TABLE public.monthly_usage (
  id uuid NOT NULL DEFAULT uuid_generate_v4(),
  user_id uuid,
  year integer NOT NULL,
  month integer NOT NULL,
  requests_count integer DEFAULT 0,
  analyze_requests integer DEFAULT 0,
  feedback_requests integer DEFAULT 0,
  plan character varying,
  amount_charged numeric,
  created_at timestamp without time zone DEFAULT now(),
  CONSTRAINT monthly_usage_pkey PRIMARY KEY (id),
  CONSTRAINT monthly_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.api_users(id)
);
CREATE TABLE public.quarantine (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  threat_id uuid,
  site_id character varying,
  file_path text,
  original_content text,
  backup_location text,
  quarantined_at timestamp without time zone DEFAULT now(),
  restored_at timestamp without time zone,
  CONSTRAINT quarantine_pkey PRIMARY KEY (id),
  CONSTRAINT quarantine_threat_id_fkey FOREIGN KEY (threat_id) REFERENCES public.threats(id)
);
CREATE TABLE public.scans (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  site_id character varying,
  scan_type character varying,
  status character varying,
  started_at timestamp without time zone DEFAULT now(),
  completed_at timestamp without time zone,
  files_scanned integer DEFAULT 0,
  threats_found integer DEFAULT 0,
  progress integer DEFAULT 0,
  results jsonb,
  CONSTRAINT scans_pkey PRIMARY KEY (id),
  CONSTRAINT scans_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.site_stats(site_id)
);
CREATE TABLE public.site_stats (
  site_id character varying NOT NULL,
  total_analyzed integer DEFAULT 0,
  total_spam_blocked integer DEFAULT 0,
  total_ham_approved integer DEFAULT 0,
  accuracy double precision,
  last_retrain timestamp without time zone,
  api_key character varying UNIQUE,
  created_at timestamp without time zone DEFAULT now(),
  CONSTRAINT site_stats_pkey PRIMARY KEY (site_id)
);
CREATE TABLE public.system_alerts (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  type character varying CHECK (type::text = ANY (ARRAY['warning'::character varying, 'error'::character varying, 'info'::character varying]::text[])),
  message text NOT NULL,
  site_id character varying,
  resolved boolean DEFAULT false,
  created_at timestamp without time zone DEFAULT now(),
  resolved_at timestamp without time zone,
  resolved_by uuid,
  CONSTRAINT system_alerts_pkey PRIMARY KEY (id),
  CONSTRAINT system_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES auth.users(id)
);
CREATE TABLE public.threats (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  scan_id uuid,
  site_id character varying,
  file_path text,
  threat_type character varying,
  severity character varying,
  signature_matched character varying,
  code_snippet text,
  status character varying,
  detected_at timestamp without time zone DEFAULT now(),
  resolved_at timestamp without time zone,
  CONSTRAINT threats_pkey PRIMARY KEY (id),
  CONSTRAINT threats_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id)
);
CREATE TABLE public.webhooks (
  id uuid NOT NULL DEFAULT uuid_generate_v4(),
  user_id uuid,
  url text NOT NULL,
  events ARRAY DEFAULT ARRAY['spam_detected'::text, 'phishing_detected'::text],
  secret character varying,
  is_active boolean DEFAULT true,
  last_triggered_at timestamp without time zone,
  success_count integer DEFAULT 0,
  failure_count integer DEFAULT 0,
  created_at timestamp without time zone DEFAULT now(),
  updated_at timestamp without time zone DEFAULT now(),
  CONSTRAINT webhooks_pkey PRIMARY KEY (id),
  CONSTRAINT webhooks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.api_users(id)
);